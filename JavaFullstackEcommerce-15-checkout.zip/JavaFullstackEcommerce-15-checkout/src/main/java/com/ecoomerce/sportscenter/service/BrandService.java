package com.ecoomerce.sportscenter.service;

import com.ecoomerce.sportscenter.model.BrandResponse;

import java.util.List;

public interface BrandService {
    List<BrandResponse> getAllBrands();
}
