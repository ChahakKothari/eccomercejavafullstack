package com.ecoomerce.sportscenter.service;

import com.ecoomerce.sportscenter.model.TypeResponse;

import java.util.List;

public interface TypeService {
    List<TypeResponse> getAllTypes();
}
