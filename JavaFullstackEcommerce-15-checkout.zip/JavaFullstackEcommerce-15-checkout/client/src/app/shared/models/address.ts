export interface Address {
    fname: String;
    lname: String;
    street: String;
    city: String;
    state: String;
    zipcode: String
}