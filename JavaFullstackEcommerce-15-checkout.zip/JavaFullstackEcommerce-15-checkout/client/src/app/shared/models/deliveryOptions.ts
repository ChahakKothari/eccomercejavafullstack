export interface DeliveryOption {
    id: number;
    name: string;
    deliveryTime: string;
    description: string;
    price: number;
}